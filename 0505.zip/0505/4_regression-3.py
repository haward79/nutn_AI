
import pandas as pd
from sklearn import linear_model
import matplotlib.pyplot as plt

dataFrame = pd.read_fwf('brain_body.txt')
xValues = dataFrame[['Body']]
yValues = dataFrame[['Brain']]

bodyReg = linear_model.LinearRegression()

bodyReg.fit(xValues, yValues)
pre = bodyReg.predict(xValues)

print(bodyReg.predict(pd.DataFrame(data=[[170]])))

plt.scatter(xValues, yValues)
plt.plot(xValues, pre)

# Show plt.
plt.show()

