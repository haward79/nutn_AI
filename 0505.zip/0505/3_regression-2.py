
import matplotlib.pyplot as plt
import numpy as np

# Plot points and line.
plt.plot([1, 2, 3, 4], [0, 0.3, 0.6, 0.9], 'gx')
plt.plot([1, 2, 3, 4], [0, 0.3, 0.6, 0.9], 'r--')

# Define x and delta.
X = np.arange(30) / 10 + 1
delta = np.random.uniform(low=-0.1, high=0.1, size=(30,))

# Calculate y.
Y = 0.3 * X - 0.3 + delta

# Draw function.
plt.plot(X, Y, 'bo')

# Label axises.
plt.xlabel('X')
plt.ylabel('Y')

# Show plot.
plt.show()

