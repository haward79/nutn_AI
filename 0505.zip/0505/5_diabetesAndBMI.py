
import matplotlib.pyplot as plt
import numpy as np
from sklearn import linear_model, datasets

# Load data of diabetes.
diabetes = datasets.load_diabetes()

# Get spec III.
diabetesX = diabetes.data[:, np.newaxis, 2]

# Split specs.
diabetesXtrain = diabetesX[:-20]
diabetesXtest = diabetesX[-20:]

# Split answer.
diabetesYtrain = diabetes.target[:-20]
diabetesYtest = diabetes.target[-20:]

# Create linear regression.
regression = linear_model.LinearRegression()

# Train.
regression.fit(diabetesXtrain, diabetesYtrain)

print('Coefficients: \n', regression.coef_)

print('Mean squared error: %.2f' % (np.mean(regression.predict(diabetesXtest)) ** 2))

print('Variance score: %.2f' % (regression.score(diabetesXtest, diabetesYtest)))

plt.scatter(diabetesXtest, diabetesYtest, color='black')
plt.plot(diabetesXtest, regression.predict(diabetesXtest), color='blue', linewidth=3)

plt.xticks(())
plt.yticks(())

# Show plt.
plt.show()

