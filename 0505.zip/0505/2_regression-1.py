
import matplotlib.pyplot as plt

# Plot points and line.
plt.plot([1, 2, 3, 4], [0, 0.3, 0.6, 0.9], 'gx')
plt.plot([1, 2, 3, 4], [0, 0.3, 0.6, 0.9], 'r--')

# Set axis range.
plt.axis([0, 5, 0, 1])

# Label axises.
plt.xlabel('X')
plt.ylabel('Y')

# Label legend.
plt.legend(('price', 'passenger'), loc='upper right')

# Show plot.
plt.show()

