
import matplotlib.pyplot as plt
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.cluster import KMeans
from sklearn import metrics

# 載入花的資料集。
iris = datasets.load_iris()

# 拆分資料 80:20，用80%資料訓練模型，用20%資料驗證答案。
iris_x_train, iris_x_test, iris_y_train, iris_y_test = train_test_split(iris.data, iris.target, test_size=0.2)

# Kmeans演算法。
kmeans = KMeans(n_clusters=3)
kmeans.fit(iris_x_train)
y_predict = kmeans.predict(iris_x_train)

x1 = iris_x_train[:, 0]
y1 = iris_x_train[:, 1]
plt.scatter(x1, y1, c=y_predict, cmap='viridis')

centers = kmeans.cluster_centers_
plt.scatter(centers[:, 0], centers[:, 1], c="black", s=200, alpha=0.5)
plt.show()

