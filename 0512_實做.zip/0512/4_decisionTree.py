
# Reference https://medium.com/analytics-vidhya/iris-data-prediction-using-decision-tree-algorithm-7948fb68201b

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# 從csv讀取資料集。
iris_data = pd.read_csv("iris_data.csv")

# 印出資料集的相關資訊。
print(iris_data.info())
print()

# 檢視前10組資料集。
print(iris_data.head(10))
print()

# 取得資料集的數值相關資訊。
print(iris_data.describe())
print()

# 針對每個標籤計數。
iris_data.Species.value_counts()

plt.scatter(iris_data['SepalLengthCm'], iris_data['SepalWidthCm'])
plt.show()

"""
    kmeans得到的結果較好。
"""

